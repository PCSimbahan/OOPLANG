//Base class
public class animal
{
    String color;
    String numberOfLegs;
    
    public animal(){
        
    }
    public animal(String color, String numberOfLegs){
        this.color = color;
        this.numberOfLegs = numberOfLegs;
    
    }
    
    public String getColor(){
        return color;
    }
    
    public String getNumberOfLegs(){
        return numberOfLegs;
    }
    
    public String setColor(){
        color = color;
        return color;
    
    }
    public String setNumberOfLegs(){
        numberOfLegs = numberOfLegs;
        return numberOfLegs;
    }
    
    public void showInfo(){
        getColor();
        setColor();
    }

}

