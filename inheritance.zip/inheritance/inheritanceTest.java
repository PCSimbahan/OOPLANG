

public class inheritanceTest
{
    public static void main(String[] args){
        dog dog1 = new dog("3", "White");
        System.out.println(dog1.getDogName());
        System.out.println(dog1.getNumberOfLegs());
        System.out.println(dog1.getColor());
        
    }
}
