
public class dog extends animal
{
    String dogName;
    
    public String setDogName(){
        this.dogName = dogName;
        return dogName;
    }
        
    public String getDogName(){
        this.dogName = dogName;
        return dogName;
    }
    
    public dog(String numberOfLegs, String color){
        super(numberOfLegs, color);    
        this.dogName = "Fluffy";
    }
    
   
}
