import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Calculator extends JFrame implements ActionListener
{
    JButton calculate,exit;
    JButton[] eventButton = new JButton[2];
    JLabel num1,num2,operator,result;
    JTextField firstNum,secondNum,operatorText,resultText;
    
    public Calculator(){
        setTitle("Simple Calculator");
        addWindowListener(new WindowAdapter(){
            public void windowClosing(WindowEvent e){
                exitForm(e);
            }
        
        
        });
        getContentPane().setLayout(new GridBagLayout());
        GridBagConstraints gridConstraints = new GridBagConstraints();
        
        num1 = new JLabel("Operand 1:");
        gridConstraints.gridx = 0;
        gridConstraints.gridy = 0;
        getContentPane().add(num1,gridConstraints);
        num2 = new JLabel("Operand 2:");
        gridConstraints.gridx = 0;
        gridConstraints.gridy = 2;
        getContentPane().add(num2,gridConstraints);
        operator = new JLabel("Operator:");
        gridConstraints.gridx = 0;
        gridConstraints.gridy = 1;
        getContentPane().add(operator,gridConstraints);
        result = new JLabel("Result:");
        gridConstraints.gridx = 0;
        gridConstraints.gridy = 3;
        getContentPane().add(result,gridConstraints);
        
        firstNum = new JTextField("");
        firstNum.setColumns(10);
        gridConstraints.gridx = 1;
        gridConstraints.gridy = 0;
        getContentPane().add(firstNum,gridConstraints);
        secondNum = new JTextField("");
        secondNum.setColumns(10);
        gridConstraints.gridx = 1;
        gridConstraints.gridy = 2;
        getContentPane().add(secondNum,gridConstraints);
        operatorText = new JTextField();
        operatorText.setColumns(5);
        gridConstraints.gridx = 1;
        gridConstraints.gridy = 1;
        getContentPane().add(operatorText,gridConstraints);
        resultText = new JTextField();
        resultText.setColumns(10);
        resultText.setEditable(false);
        gridConstraints.gridx = 1;
        gridConstraints.gridy = 3;
        getContentPane().add(resultText,gridConstraints);
        
        
        calculate = new JButton("Calculate");
        gridConstraints.gridx = 0;
        gridConstraints.gridy = 4;
        getContentPane().add(calculate,gridConstraints);
        exit = new JButton("Exit");
        gridConstraints.gridx = 1;
        gridConstraints.gridy = 4;
        getContentPane().add(exit,gridConstraints);
        
        eventButton[0] = calculate;
        eventButton[1] = exit;
        
        for(int i = 0; i < 2; i++){
            eventButton[i].addActionListener(this);
        }
        pack();
    }

    public static void main(String[] args){
        new Calculator().show();
    }
    
    public void exitForm(WindowEvent e){
        JFrame f = new JFrame();
        JOptionPane.showMessageDialog(f,"Exiting Module");
    }
    public void actionPerformed(ActionEvent e){
    
        if(e.getSource() == exit){
            JFrame f = new JFrame();
            JOptionPane.showMessageDialog(f,"Exiting Program, GoodBye!!");
            System.exit(0);
        }
        
        int num1 = Integer.parseInt(firstNum.getText());
        int num2 = Integer.parseInt(secondNum.getText());
    
        if(e.getSource() == calculate){
            if(operatorText.getText().equals("+")){
                resultText.setText("" +(num1+num2));
            }
            else if(operatorText.getText().equals("-")){
                resultText.setText(""+(num1-num2));
            }
            else if(operatorText.getText().equals("*")){
                resultText.setText(""+(num1*num2));
            }
            else if(operatorText.getText().equals("/")){
                resultText.setText(""+(num1/num2));
            }
            
       }
        
    }
    
}
